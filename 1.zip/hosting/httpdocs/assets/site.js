(() => {
  const $ = (s, r=document) => r.querySelector(s);
  const $$ = (s, r=document) => [...r.querySelectorAll(s)];
  const menu = $("#menu");
  $("#menu-open")?.addEventListener("click", () => menu?.classList.add("on"));
  $("#menu-close")?.addEventListener("click", () => menu?.classList.remove("on"));
  $$("#menu a").forEach(a => a.addEventListener("click", () => menu?.classList.remove("on")));

  function openDialog(id) {
    $("#overlay")?.classList.add("on");
    $(id)?.classList.add("on");
  }
  function closeDialogs() {
    $("#overlay")?.classList.remove("on");
    $$(".dialog").forEach(d => d.classList.remove("on"));
  }
  $("#overlay")?.addEventListener("click", closeDialogs);
  $$("[data-close]").forEach(b => b.addEventListener("click", closeDialogs));
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") closeDialogs();
    if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
      e.preventDefault();
      openSearch();
    }
  });
  $$("[data-search]").forEach(b => b.addEventListener("click", openSearch));
  $$("[data-quote]").forEach(b => b.addEventListener("click", () => {
    const title = b.getAttribute("data-quote") || "";
    const p = $("#quote-product");
    if (p) p.value = title;
    const hint = $("#quote-hint");
    if (hint) hint.textContent = title ? ("Позиция: " + title) : "Опишите задачу клиники.";
    openDialog("#quote");
  }));

  async function openSearch() {
    openDialog("#search-dlg");
    const input = $("#search-dlg input");
    input?.focus();
    if (!window.__products) {
      try {
        const res = await fetch("/assets/products.json");
        window.__products = await res.json();
      } catch { window.__products = []; }
    }
    renderSearch(input?.value || "");
  }
  $("#search-dlg input")?.addEventListener("input", (e) => renderSearch(e.target.value));
  function renderSearch(q) {
    const box = $("#search-results");
    if (!box) return;
    const s = q.trim().toLowerCase();
    const list = (window.__products || []).filter(p => {
      if (!s) return true;
      return (p.title + " " + p.excerpt + " " + p.category).toLowerCase().includes(s);
    }).slice(0, 12);
    box.innerHTML = list.length
      ? list.map(p => '<a href="/product/'+p.slug+'/">'+escapeHtml(p.title)+"</a>").join("")
      : '<p class="muted small">Ничего не найдено</p>';
  }
  function escapeHtml(t){return String(t).replace(/[&<>"]/g,c=>({amp:"&amp;",lt:"&lt;",gt:"&gt;",quot:"&quot;"}[{"&":"amp","<":"lt",">":"gt",'"':"quot"}[c]]))}

  const qInput = $("#cat-q");
  function filterCards() {
    const q = (qInput?.value || "").trim().toLowerCase();
    let n = 0;
    $$("[data-card]").forEach(el => {
      const hay = (el.getAttribute("data-hay") || "");
      const ok = !q || hay.includes(q);
      el.classList.toggle("hide", !ok);
      if (ok) n++;
    });
    const c = $("#cat-count");
    if (c) c.textContent = n ? (n + " поз.") : "Ничего не найдено";
  }
  qInput?.addEventListener("input", filterCards);

  async function sendForm(form, okMsg) {
    const data = new FormData(form);
    data.set("_gotcha", "");
    const btn = form.querySelector("[type=submit]");
    if (btn) btn.disabled = true;
    try {
      const res = await fetch(form.action, { method: "POST", body: data, headers: { Accept: "application/json" } });
      if (!res.ok) throw new Error("fail");
      alert(okMsg);
      form.reset();
      closeDialogs();
    } catch {
      alert("Не отправилось. Позвоните или напишите в WhatsApp.");
    } finally {
      if (btn) btn.disabled = false;
    }
  }
  $("#quote-form")?.addEventListener("submit", (e) => {
    e.preventDefault();
    sendForm(e.currentTarget, "Заявка отправлена. Свяжемся в рабочие часы.");
  });
  $("#contact-form")?.addEventListener("submit", (e) => {
    e.preventDefault();
    sendForm(e.currentTarget, "Сообщение отправлено. Ответим в рабочие часы.");
  });
})();
