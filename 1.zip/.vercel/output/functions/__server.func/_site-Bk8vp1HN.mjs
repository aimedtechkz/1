import { v as require_jsx_runtime } from "./_libs/@radix-ui/react-accordion+[...].mjs";
import { v as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { A as BadgeCheck, M as ArrowRight, c as Search, n as Truck, y as Headset } from "./_libs/lucide-react.mjs";
import { l as CATEGORIES, u as PRODUCT_COUNT } from "./_ssr/router-BUVEzBZF.mjs";
import { t as Button } from "./_ssr/button-BSU5c3iW.mjs";
import { t as useQuoteStore } from "./_ssr/quote-store-i1dOwMSC.mjs";
import { n as ProductCard, r as ProductImage } from "./_ssr/product-card-DRhRy_Pa.mjs";
import { t as CATEGORY_ICONS } from "./_ssr/category-icons-B5LSpAgo.mjs";
import { t as COMPANY } from "./_ssr/company-CGvzJYrU.mjs";
import { t as useSearchStore } from "./_ssr/search-store-DjEMje_B.mjs";
import { t as FaqList } from "./_ssr/faq-list-KlhD4f6V.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_site-Bk8vp1HN.js
var import_jsx_runtime = require_jsx_runtime();
var featured = [
	{
		"id": "elektricheskii-ginekologicheskii-operacionnyi-stol",
		"slug": "elektricheskii-ginekologicheskii-operacionnyi-stol",
		"category": "gynecology",
		"title": "Электрический гинекологический операционный стол",
		"titleOriginal": null,
		"excerpt": "Специализированный стол с электроприводом для гинекологических процедур.",
		"description": "Electric gynecological operating table. Регулируемые ножные опоры, удобное положение пациента, легко моющаяся поверхность.",
		"image": "https://aimedtech.kz/images/maya-electric-gynecological-table.jpg",
		"imageFile": "maya-electric-gynecological-table.jpg",
		"alt": "Электрический гинекологический стол",
		"featured": false
	},
	{
		"id": "stomatologicheskaya-ustanovka-polnyi-komplekt",
		"slug": "stomatologicheskaya-ustanovka-polnyi-komplekt",
		"category": "dentistry",
		"title": "Стоматологическая установка (полный комплект)",
		"titleOriginal": null,
		"excerpt": "Современное кресло с LED-освещением, наконечниками и компрессором.",
		"description": "Dental Complete Set. Включает кресло, LED-отбеливание, эндоскоп, компрессор без масла, набор наконечников. Полностью готово к работе.",
		"image": "https://aimedtech.kz/images/maya-dental-chair.jpg",
		"imageFile": "maya-dental-chair.jpg",
		"alt": "Стоматологическая установка (Dental Complete Set)",
		"featured": true
	},
	{
		"id": "schelevaya-lampa-slit-lamp",
		"slug": "schelevaya-lampa-slit-lamp",
		"category": "ophthalmology",
		"title": "Щелевая лампа (Slit Lamp)",
		"titleOriginal": null,
		"excerpt": "Профессиональная щелевая лампа для диагностики переднего отрезка глаза.",
		"description": "Высококачественная оптика, регулируемая щель, возможность подключения камеры. Стандарт для офтальмологических кабинетов.",
		"image": "https://aimedtech.kz/images/maya-slit-lamp.jpg",
		"imageFile": "maya-slit-lamp.jpg",
		"alt": "Щелевая лампа",
		"featured": true
	},
	{
		"id": "videogastroskop-kolonoskop",
		"slug": "videogastroskop-kolonoskop",
		"category": "diagnostics",
		"title": "Видеогастроскоп / Колоноскоп",
		"titleOriginal": null,
		"excerpt": "Медицинский волоконно-оптический видеогастроскоп. Эндоскопическая система. Комплект камеры.",
		"description": "Описание товара: Улучшение гемоглобина (HBE) - выделение кровеносных сосудов и зон с активным кровоснабжением; Подчеркивание контура и структуры - чёткое отображение границ и волокнистых структур; Регулировка цветности и яркости - по индивидуальным предпочтениям; Режимы замера экспозиции: усреднённый / пиковый; USB-функция - сохранение видео и фото в реальном времени; Стабильность изображения - устранение дефектных пикселей, чёткие замороженные кадры. Технические параметры: Параметр ВМЭ-98С ВМЭ-1300С; Диаметр дистального конца ø9,6 мм ø12,8 мм; Диаметр вставной трубки ø9,6 мм ø12,8 мм; Биопсийный канал ø2,8 мм ø3,7 мм; Рабочая длина 1050 мм 1300 мм; Глубина обзора 3–100 мм 3–100 мм; Отклонение кончика U:210° D:90° L/R:100° U:180° D:180° L/R:160°. Стандартная конфигурация: Зарядное устройство — 1 шт; Руководство пользователя — 1 шт.",
		"image": "https://aimedtech.kz/images/Video%20Gastroscope%20Colonoscope.jpg",
		"imageFile": "Video Gastroscope Colonoscope.jpg",
		"alt": "Video Gastroscope Colonoscope для Урология",
		"featured": true
	},
	{
		"id": "laparoscope",
		"slug": "laparoscope",
		"category": "surgery",
		"title": "Лапароскоп",
		"titleOriginal": "Laparoscope",
		"excerpt": "Корпус эндоскопа изготовлен из нержавеющей стали. В зеркале используются немецкое оптическое стекло, оптическое волокно и световой конус.",
		"description": "Благодаря использованию запатентованной технологии цилиндрической линзы изображение получается четким, а поле зрения ярким. С указателями направления и сапфировыми линзами. Опциональный эндоскоп для дезинфекции плазмой высокой температуры, высокого давления и низкой температуры.",
		"image": "https://aimedtech.kz/images/Laparoscope.jpg",
		"imageFile": "Laparoscope.jpg",
		"alt": "Laparoscope для Хирургия",
		"featured": false
	},
	{
		"id": "shkaf-kartotechnyi-4-yaschichnyi-seryi",
		"slug": "shkaf-kartotechnyi-4-yaschichnyi-seryi",
		"category": "furniture",
		"title": "Шкаф картотечный 4-ящичный (серый)",
		"titleOriginal": null,
		"excerpt": "Надёжный картотечный шкаф для систематизированного хранения медицинских карт, архивных документов и важной документации.",
		"description": "Обеспечивает полное выдвижение ящиков, центральный замок и механизм антиопрокидывания для максимальной безопасности. Идеален для регистратуры, архива и приёмного отделения. Характеристики: 1335×465×630 мм, сталь, 4 ящика, нагрузка до 30 кг/ящик, цвет RAL 7035",
		"image": "https://aimedtech.kz/images/001.jpg",
		"imageFile": "001.jpg",
		"alt": "Шкаф картотечный 4-ящичный",
		"featured": true
	}
];
var mosaic = featured.slice(0, 3);
function Home() {
	const openFor = useQuoteStore((s) => s.openFor);
	const setSearchOpen = useSearchStore((s) => s.setOpen);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "relative overflow-hidden bg-ink text-card",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-0 hero-grid opacity-50" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative mx-auto grid max-w-6xl items-center gap-12 px-4 pb-16 pt-14 sm:px-6 lg:grid-cols-12 lg:pb-20 lg:pt-20",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "lg:col-span-7",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "reveal text-xs font-medium uppercase tracking-widest text-mist",
								children: "Алматы · поставка в клиники Казахстана"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
								className: "reveal mt-5 font-display text-5xl font-medium leading-tight tracking-tight sm:text-6xl lg:text-7xl",
								children: [
									"Оборудование,",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
									"на котором",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
									"работает отделение"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "reveal mt-6 max-w-xl text-base leading-relaxed text-card/70 sm:text-lg",
								children: COMPANY.description
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "reveal mt-8 flex flex-wrap gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									asChild: true,
									size: "lg",
									className: "bg-card text-ink hover:bg-card/90",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
										to: "/catalog",
										children: ["Открыть каталог", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {})]
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									size: "lg",
									variant: "outline",
									className: "border-card/20 bg-transparent text-card hover:bg-card/10",
									onClick: () => setSearchOpen(true),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {}), "Найти модель"]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
								className: "reveal mt-12 grid grid-cols-2 gap-6 sm:grid-cols-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
										value: String(PRODUCT_COUNT),
										label: "позиций"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
										value: String(CATEGORIES.length),
										label: "направлений"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
										value: "1 день",
										label: "на КП"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
										value: COMPANY.city,
										label: "база"
									})
								]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "lg:col-span-5",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-3",
							children: [mosaic[0] ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/product/$slug",
								params: { slug: mosaic[0].slug },
								className: "col-span-2 overflow-hidden rounded-xl bg-card/5 shadow-[var(--shadow-ink)]",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductImage, {
									src: mosaic[0].image,
									alt: mosaic[0].alt,
									className: "aspect-[16/10] bg-card/5",
									zoom: true
								})
							}) : null, mosaic.slice(1, 3).map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/product/$slug",
								params: { slug: p.slug },
								className: "overflow-hidden rounded-lg bg-card/5 shadow-[var(--shadow-ink)]",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductImage, {
									src: p.image,
									alt: p.alt,
									className: "aspect-square bg-card/5",
									zoom: true
								})
							}, p.slug))]
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "relative border-t border-card/10",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "overflow-hidden py-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "marquee-track flex w-max gap-10 px-6 text-xs font-medium uppercase tracking-widest text-card/50",
							children: [...CATEGORIES, ...CATEGORIES].map((c, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center gap-10",
								children: [c.name, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-mist",
									children: "·"
								})]
							}, `${c.id}-${i}`))
						})
					})
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto max-w-6xl px-4 py-16 sm:px-6 sm:py-20",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-end justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium uppercase tracking-widest text-primary",
					children: "15 направлений"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-2 font-sans text-3xl font-semibold tracking-tight text-foreground sm:text-4xl",
					children: "Подберите по отделению"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					variant: "ghost",
					className: "hidden sm:inline-flex",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/catalog",
						children: ["Весь каталог", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {})]
					})
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-10 grid gap-3 sm:grid-cols-2 lg:grid-cols-3",
				children: CATEGORIES.map((c) => {
					const Icon = CATEGORY_ICONS[c.id];
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/catalog/$category",
						params: { category: c.id },
						className: "group flex h-full items-start gap-4 rounded-xl bg-card p-5 shadow-[var(--shadow-border)] transition-[box-shadow,transform] duration-200 hover:shadow-[var(--shadow-border-hover)]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "flex size-10 shrink-0 items-center justify-center rounded-md bg-muted text-primary",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-medium text-foreground",
									children: c.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "tabular-nums text-sm text-muted-foreground",
									children: c.count
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-1 block text-sm text-muted-foreground",
								children: c.blurb
							})]
						})]
					}) }, c.id);
				})
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "border-y border-border bg-card/40",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-6xl px-4 py-16 sm:px-6 sm:py-20",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-end justify-between gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-widest text-primary",
						children: "Витрина"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-2 font-sans text-3xl font-semibold tracking-tight text-foreground sm:text-4xl",
						children: "Избранные позиции"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						variant: "ghost",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/catalog",
							children: [
								"Все ",
								PRODUCT_COUNT,
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {})
							]
						})
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3",
					children: featured.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductCard, { product: p }, p.slug))
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto max-w-6xl px-4 py-16 sm:px-6 sm:py-20",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium uppercase tracking-widest text-primary",
					children: "Процесс"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-2 font-sans text-3xl font-semibold tracking-tight text-foreground sm:text-4xl",
					children: "От заявки до работающего кабинета"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-10 grid gap-6 md:grid-cols-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Feature, {
							icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Truck, { className: "size-5" }),
							step: "01",
							title: "Поставка",
							text: "Комплектация кабинета или отделения: от мебели до эндоскопических стоек."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Feature, {
							icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Headset, { className: "size-5" }),
							step: "02",
							title: "Сервис",
							text: "Гарантийное и постгарантийное обслуживание, расходные материалы."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Feature, {
							icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BadgeCheck, { className: "size-5" }),
							step: "03",
							title: "Обучение",
							text: "Ввод персонала в работу с оборудованием после поставки."
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-10 flex flex-wrap gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/services",
							children: "Услуги"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						onClick: () => openFor(null),
						children: "Оставить заявку"
					})]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "border-t border-border bg-card/40",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto grid max-w-6xl gap-10 px-4 py-16 sm:px-6 sm:py-20 lg:grid-cols-12",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "lg:col-span-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-medium uppercase tracking-widest text-primary",
							children: "Вопросы"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-2 font-sans text-3xl font-semibold tracking-tight text-foreground sm:text-4xl",
							children: "Коротко о поставке"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-sm leading-relaxed text-muted-foreground",
							children: "Каталог информационный. Цена, комплектация и сроки — в коммерческом предложении под ваш объект."
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "lg:col-span-7",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FaqList, {})
				})]
			})
		})
	] });
}
function Stat({ value, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
		className: "text-xs uppercase tracking-wider text-card/45",
		children: label
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
		className: "mt-1 font-display text-2xl tabular-nums tracking-tight",
		children: value
	})] });
}
function Feature({ icon, step, title, text }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl bg-card p-6 shadow-[var(--shadow-border)]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex size-10 items-center justify-center rounded-md bg-muted text-primary",
					children: icon
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-mono text-xs text-muted-foreground",
					children: step
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "mt-5 font-sans text-xl font-semibold",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm leading-relaxed text-muted-foreground",
				children: text
			})
		]
	});
}
//#endregion
export { Home as component };
