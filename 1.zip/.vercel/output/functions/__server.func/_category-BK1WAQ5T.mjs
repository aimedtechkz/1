import { v as require_jsx_runtime } from "./_libs/@radix-ui/react-accordion+[...].mjs";
import { r as Route$1 } from "./_ssr/router-BUVEzBZF.mjs";
import { t as CatalogView } from "./_ssr/catalog-view-Dkd-XRET.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_category-BK1WAQ5T.js
var import_jsx_runtime = require_jsx_runtime();
function CategoryPage() {
	const { cat, count } = Route$1.useLoaderData();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CatalogView, {
		categoryId: cat.id,
		title: cat.name,
		lead: `${cat.blurb}. В разделе ${count} позиций.`
	});
}
//#endregion
export { CategoryPage as component };
