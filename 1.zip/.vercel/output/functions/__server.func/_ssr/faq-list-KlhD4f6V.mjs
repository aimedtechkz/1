import { i as __toESM } from "../_runtime.mjs";
import { a as Trigger2, i as Root2, n as Header, r as Item, t as Content2, v as require_jsx_runtime, y as require_react } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { D as ChevronDown } from "../_libs/lucide-react.mjs";
import { n as cn } from "./button-BSU5c3iW.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/faq-list-KlhD4f6V.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Accordion = Root2;
var AccordionItem = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item, {
	ref,
	className: cn("border-b border-border", className),
	...props
}));
AccordionItem.displayName = "AccordionItem";
var AccordionTrigger = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Header, {
	className: "flex",
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Trigger2, {
		ref,
		className: cn("flex flex-1 items-center justify-between gap-4 py-5 text-left text-base font-medium transition-colors hover:text-primary [&[data-state=open]>svg]:rotate-180", className),
		...props,
		children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "size-4 shrink-0 text-muted-foreground transition-transform duration-200" })]
	})
}));
AccordionTrigger.displayName = Trigger2.displayName;
var AccordionContent = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content2, {
	ref,
	className: "overflow-hidden text-sm text-muted-foreground data-[state=closed]:animate-accordion-up data-[state=open]:animate-accordion-down",
	...props,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("pb-5 leading-relaxed", className),
		children
	})
}));
AccordionContent.displayName = Content2.displayName;
var FAQ = [
	{
		q: "Как получить коммерческое предложение?",
		a: "Откройте карточку оборудования и нажмите «Запросить КП», либо напишите в WhatsApp. Укажите отделение и количество — спецификацию готовим в течение рабочего дня."
	},
	{
		q: "Почему на сайте нет цен?",
		a: "Комплектация, логистика и регистрационные документы зависят от объекта. Публичная цена ввела бы в заблуждение. Стоимость фиксируем в КП под вашу задачу."
	},
	{
		q: "Работаете ли вы с регионами Казахстана?",
		a: "Да. База в Алматы, поставка по стране. Срок и условия доставки согласуем в спецификации."
	},
	{
		q: "Есть ли сервис и обучение?",
		a: "Гарантийное и постгарантийное обслуживание, расходные материалы и ввод персонала в работу с поставленным оборудованием — часть поставки, не отдельная «опция»."
	}
];
function FaqList() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Accordion, {
		type: "single",
		collapsible: true,
		className: "w-full",
		children: FAQ.map((item, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AccordionItem, {
			value: `faq-${i}`,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccordionTrigger, { children: item.q }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccordionContent, { children: item.a })]
		}, item.q))
	});
}
//#endregion
export { FaqList as t };
