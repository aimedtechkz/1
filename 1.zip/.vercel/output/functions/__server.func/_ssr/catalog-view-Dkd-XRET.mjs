import { i as __toESM } from "../_runtime.mjs";
import { v as require_jsx_runtime, y as require_react } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as Search, s as SlidersHorizontal } from "../_libs/lucide-react.mjs";
import { c as sortProducts, l as CATEGORIES, s as searchProducts } from "./router-BUVEzBZF.mjs";
import { n as cn, t as Button } from "./button-BSU5c3iW.mjs";
import { t as Input } from "./input-CWfuIPqh.mjs";
import { n as ProductCard } from "./product-card-DRhRy_Pa.mjs";
import { t as CATEGORY_ICONS } from "./category-icons-B5LSpAgo.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/catalog-view-Dkd-XRET.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function CatalogView({ categoryId, title, lead }) {
	const [query, setQuery] = (0, import_react.useState)("");
	const [sort, setSort] = (0, import_react.useState)("relevance");
	const [visible, setVisible] = (0, import_react.useState)(12);
	const results = (0, import_react.useMemo)(() => {
		const found = searchProducts(query, categoryId ?? "all");
		return sortProducts(found, sort);
	}, [
		query,
		categoryId,
		sort
	]);
	const shown = results.slice(0, visible);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
		className: "border-b border-border bg-ink text-card",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-6xl px-4 py-12 sm:px-6 sm:py-16",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium uppercase tracking-widest text-mist",
					children: "Каталог"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-3 font-display text-4xl font-medium tracking-tight sm:text-5xl",
					children: title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 max-w-2xl text-base leading-relaxed text-card/70",
					children: lead
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative mt-8 max-w-lg",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-card/50" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: query,
						onChange: (e) => {
							setQuery(e.target.value);
							setVisible(12);
						},
						placeholder: "Поиск по названию, модели, назначению",
						className: "border-card/15 bg-card/10 pl-10 text-card placeholder:text-card/45 focus-visible:ring-mist",
						type: "search",
						"aria-label": "Поиск в каталоге"
					})]
				})
			]
		})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-6xl px-4 py-8 sm:px-6 lg:grid lg:grid-cols-12 lg:gap-10",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
			className: "hidden lg:col-span-3 lg:block",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "sticky top-24 rounded-xl bg-card p-4 shadow-[var(--shadow-border)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "px-2 text-xs font-medium uppercase tracking-wider text-muted-foreground",
					children: "Направления"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "mt-3 grid gap-0.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/catalog",
						className: sideClass(!categoryId),
						children: "Все позиции"
					}) }), CATEGORIES.map((c) => {
						const Icon = CATEGORY_ICONS[c.id];
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/catalog/$category",
							params: { category: c.id },
							className: sideClass(categoryId === c.id),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-3.5 shrink-0 opacity-70" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "flex-1 truncate",
									children: c.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "tabular-nums text-xs opacity-70",
									children: c.count
								})
							]
						}) }, c.id);
					})]
				})]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "lg:col-span-9",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-4 flex flex-wrap gap-2 lg:hidden",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/catalog",
						className: chipClass(!categoryId),
						children: "Все"
					}), CATEGORIES.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/catalog/$category",
						params: { category: c.id },
						className: chipClass(categoryId === c.id),
						children: c.name
					}, c.id))]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-6 flex flex-wrap items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: results.length ? `${results.length} ${plural(results.length, "позиция", "позиции", "позиций")}` : "Ничего не найдено — измените запрос или категорию"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex items-center gap-2 text-sm text-muted-foreground",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlidersHorizontal, { className: "size-3.5" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "sr-only",
								children: "Сортировка"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								value: sort,
								onChange: (e) => setSort(e.target.value),
								className: "h-10 rounded-md border border-input bg-card px-3 text-sm text-foreground",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "relevance",
										children: "По релевантности"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "name",
										children: "По названию"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "category",
										children: "По направлению"
									})
								]
							})
						]
					})]
				}),
				shown.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-5 sm:grid-cols-2",
					children: shown.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductCard, { product: p }, p.slug))
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl border border-dashed border-border bg-card px-6 py-16 text-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-xl",
						children: "Нет совпадений"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted-foreground",
						children: "Попробуйте другое слово или откройте категорию целиком."
					})]
				}),
				visible < results.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-10 flex justify-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						onClick: () => setVisible((v) => v + 12),
						children: ["Показать ещё · ", results.length - visible]
					})
				}) : null
			]
		})]
	})] });
}
function chipClass(active) {
	return cn("shrink-0 rounded-full border px-3.5 py-2 text-sm font-medium transition-colors", active ? "border-primary bg-primary text-primary-foreground" : "border-border bg-card text-foreground hover:border-primary/40");
}
function sideClass(active) {
	return cn("flex items-center gap-2 rounded-md px-2 py-2 text-sm transition-colors", active ? "bg-primary text-primary-foreground" : "text-foreground hover:bg-muted");
}
function plural(n, one, few, many) {
	const n10 = n % 10;
	const n100 = n % 100;
	if (n10 === 1 && n100 !== 11) return one;
	if (n10 >= 2 && n10 <= 4 && (n100 < 12 || n100 > 14)) return few;
	return many;
}
//#endregion
export { CatalogView as t };
