import { v as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { u as PRODUCT_COUNT } from "./router-BUVEzBZF.mjs";
import { t as CatalogView } from "./catalog-view-Dkd-XRET.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/catalog-DK0OLR2W.js
var import_jsx_runtime = require_jsx_runtime();
function CatalogIndex() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CatalogView, {
		title: "Каталог оборудования",
		lead: `Полная линейка: ${PRODUCT_COUNT} позиций. Цены и конфигурация — в коммерческом предложении.`
	});
}
//#endregion
export { CatalogIndex as component };
