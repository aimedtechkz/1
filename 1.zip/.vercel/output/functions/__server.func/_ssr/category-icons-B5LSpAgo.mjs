import { C as Ear, F as Activity, N as Armchair, O as Bone, P as Ambulance, S as Eye, _ as Lamp, a as Stethoscope, i as TestTube, k as Bandage, l as Scissors, o as Smile, u as ScanLine, v as HeartPulse, w as Droplets } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/category-icons-B5LSpAgo.js
var CATEGORY_ICONS = {
	furniture: Armchair,
	urology: Droplets,
	gynecology: HeartPulse,
	ent: Ear,
	orthopedics: Bone,
	diagnostics: ScanLine,
	resuscitation: Activity,
	therapy: Stethoscope,
	surgery: Scissors,
	traumatology: Bandage,
	laboratory: TestTube,
	dentistry: Smile,
	ophthalmology: Eye,
	electrical: Lamp,
	transport: Ambulance
};
//#endregion
export { CATEGORY_ICONS as t };
