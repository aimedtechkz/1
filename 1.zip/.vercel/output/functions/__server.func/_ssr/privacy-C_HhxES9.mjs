import { v as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { t as COMPANY } from "./company-CGvzJYrU.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/privacy-C_HhxES9.js
var import_jsx_runtime = require_jsx_runtime();
function PrivacyPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-3xl px-4 py-16 sm:px-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium uppercase tracking-widest text-primary",
				children: "Документы"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-3 font-display text-4xl font-medium tracking-tight",
				children: "Обработка персональных данных"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 space-y-4 text-sm leading-relaxed text-muted-foreground",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [COMPANY.name, " обрабатывает данные, которые вы оставляете в формах сайта (имя, телефон, email, название организации, текст обращения), исключительно чтобы ответить на заявку и подготовить коммерческое предложение."] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Сообщения с формы уходят через сервис Formspree. Мы не ведём рекламную рассылку, не продаём списки контактов и не подключаем аналитику без отдельного уведомления." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
						"Оператор связи: ",
						COMPANY.email,
						", ",
						COMPANY.phoneDisplay,
						",",
						" ",
						COMPANY.address,
						". Чтобы уточнить, исправить или удалить данные заявки, напишите на ",
						COMPANY.email,
						"."
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Каталог носит информационный характер и не является публичной офертой. Характеристики оборудования уточняются при согласовании спецификации." })
				]
			})
		]
	});
}
//#endregion
export { PrivacyPage as component };
