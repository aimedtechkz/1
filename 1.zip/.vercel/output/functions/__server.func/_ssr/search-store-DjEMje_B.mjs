import { t as create } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/search-store-DjEMje_B.js
var useSearchStore = create((set) => ({
	open: false,
	setOpen: (open) => set({ open })
}));
//#endregion
export { useSearchStore as t };
