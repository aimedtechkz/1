import { t as create } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/quote-store-i1dOwMSC.js
var useQuoteStore = create((set) => ({
	open: false,
	product: null,
	openFor: (product = null) => set({
		open: true,
		product
	}),
	close: () => set({ open: false })
}));
//#endregion
export { useQuoteStore as t };
