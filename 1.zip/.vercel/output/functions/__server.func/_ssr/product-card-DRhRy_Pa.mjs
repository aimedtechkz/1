import { i as __toESM } from "../_runtime.mjs";
import { v as require_jsx_runtime, y as require_react } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { f as Package, j as ArrowUpRight } from "../_libs/lucide-react.mjs";
import { d as getCategory } from "./router-BUVEzBZF.mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { n as cn, t as Button } from "./button-BSU5c3iW.mjs";
import { t as useQuoteStore } from "./quote-store-i1dOwMSC.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/product-card-DRhRy_Pa.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var badgeVariants = cva("inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-medium tracking-wide", {
	variants: { variant: {
		default: "border-transparent bg-primary text-primary-foreground",
		outline: "border-border text-muted-foreground bg-transparent",
		muted: "border-transparent bg-muted text-muted-foreground"
	} },
	defaultVariants: { variant: "outline" }
});
function Badge({ className, variant, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn(badgeVariants({ variant }), className),
		...props
	});
}
function ProductImage({ src, alt, className, imgClassName, zoom = false }) {
	const [failed, setFailed] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("relative overflow-hidden bg-muted", zoom && "group/img", className),
		children: !failed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src,
			alt,
			loading: "lazy",
			decoding: "async",
			className: cn("h-full w-full object-contain transition-transform duration-500 ease-[cubic-bezier(0.22,1,0.36,1)]", zoom && "group-hover/img:scale-105", imgClassName),
			onError: () => setFailed(true)
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex h-full min-h-40 w-full items-center justify-center text-muted-foreground",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Package, { className: "size-10 opacity-40" })
		})
	});
}
function ProductCard({ product }) {
	const category = getCategory(product.category);
	const openFor = useQuoteStore((s) => s.openFor);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "group flex h-full flex-col overflow-hidden rounded-xl bg-card shadow-[var(--shadow-border)] transition-[box-shadow,transform] duration-200 ease-[cubic-bezier(0.22,1,0.36,1)] hover:shadow-[var(--shadow-border-hover)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			to: "/product/$slug",
			params: { slug: product.slug },
			className: "relative block",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductImage, {
				src: product.image,
				alt: product.alt,
				className: "aspect-[4/3]",
				zoom: true
			}), category ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
				className: "absolute left-3 top-3 bg-card/90 backdrop-blur-sm",
				variant: "outline",
				children: category.name
			}) : null]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-1 flex-col gap-3 p-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-sans text-base font-semibold leading-snug tracking-tight text-foreground",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/product/$slug",
						params: { slug: product.slug },
						className: "transition-colors hover:text-primary",
						children: product.title
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "line-clamp-3 flex-1 text-sm leading-relaxed text-muted-foreground",
					children: product.excerpt
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-1 flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						variant: "outline",
						size: "sm",
						className: "flex-1",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/product/$slug",
							params: { slug: product.slug },
							children: ["Подробнее", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, {})]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						className: "flex-1",
						onClick: () => openFor(product),
						children: "Запросить КП"
					})]
				})
			]
		})]
	});
}
//#endregion
export { ProductCard as n, ProductImage as r, Badge as t };
