import { v as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { t as Button } from "./button-BSU5c3iW.mjs";
import { t as useQuoteStore } from "./quote-store-i1dOwMSC.mjs";
import { t as FaqList } from "./faq-list-KlhD4f6V.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/services-BYO3vXKc.js
var import_jsx_runtime = require_jsx_runtime();
var ITEMS = [
	{
		title: "Поставка оборудования",
		text: "Подбор и комплектация от ведущих производителей. Согласование спецификации под процедуры отделения, логистика до объекта."
	},
	{
		title: "Сервисное обслуживание",
		text: "Гарантийный и постгарантийный ремонт, расходные материалы, техническая поддержка по поставленным позициям."
	},
	{
		title: "Обучение персонала",
		text: "Ввод врачей и среднего персонала в работу с поставленным оборудованием — на площадке клиники."
	},
	{
		title: "Оснащение «под ключ»",
		text: "Кабинет или операционный блок: мебель, мойки, свет, стойки, инструменты — единым проектом."
	}
];
function ServicesPage() {
	const openFor = useQuoteStore((s) => s.openFor);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
		className: "border-b border-border bg-ink text-card",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-6xl px-4 py-14 sm:px-6 sm:py-20",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium uppercase tracking-widest text-mist",
					children: "Услуги"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-3 max-w-2xl font-display text-4xl font-medium tracking-tight sm:text-6xl",
					children: "От заявки до работающего кабинета"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 max-w-xl text-card/70",
					children: "Не продаём оборудование в отрыве от внедрения. Поставка, сервис и обучение — одна цепочка."
				})
			]
		})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-6xl px-4 py-14 sm:px-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "grid gap-5 md:grid-cols-2",
				children: ITEMS.map((item, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rounded-xl bg-card p-8 shadow-[var(--shadow-border)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-mono text-xs text-primary",
							children: ["0", i + 1]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-3 font-sans text-2xl font-semibold",
							children: item.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm leading-relaxed text-muted-foreground",
							children: item.text
						})
					]
				}, item.title))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-10",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "lg",
					onClick: () => openFor(null),
					children: "Обсудить задачу"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-20 grid gap-10 lg:grid-cols-12",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "lg:col-span-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-sans text-3xl font-semibold tracking-tight text-foreground",
						children: "Частые вопросы"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-muted-foreground",
						children: "Если не нашли ответ — напишите, разберём ваш случай отдельно."
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "lg:col-span-7",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FaqList, {})
				})]
			})
		]
	})] });
}
//#endregion
export { ServicesPage as component };
