import { i as __toESM } from "./_runtime.mjs";
import { v as require_jsx_runtime, y as require_react } from "./_libs/@radix-ui/react-accordion+[...].mjs";
import { v as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { E as ChevronRight } from "./_libs/lucide-react.mjs";
import { a as parseDescription, d as getCategory, i as getProduct, n as Route } from "./_ssr/router-BUVEzBZF.mjs";
import { t as Button } from "./_ssr/button-BSU5c3iW.mjs";
import { t as useQuoteStore } from "./_ssr/quote-store-i1dOwMSC.mjs";
import { n as ProductCard, r as ProductImage, t as Badge } from "./_ssr/product-card-DRhRy_Pa.mjs";
import { t as COMPANY } from "./_ssr/company-CGvzJYrU.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_slug-tgMi7-Kz.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Breadcrumbs({ items }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
		"aria-label": "Навигация",
		className: "flex flex-wrap items-center gap-1 text-sm text-muted-foreground",
		children: items.map((item, i) => {
			const last = i === items.length - 1;
			let node = item.label;
			if (!last && item.to) node = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: item.to,
				params: item.params,
				className: "hover:text-foreground",
				children: item.label
			});
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_react.Fragment, { children: [i > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-3.5 opacity-60" }) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: last ? "text-foreground" : void 0,
				children: node
			})] }, `${item.label}-${i}`);
		})
	});
}
var KEY = "aimedtech-recent";
var LIMIT = 8;
function pushRecent(slug) {
	if (typeof window === "undefined") return;
	const next = [slug, ...readSlugs().filter((s) => s !== slug)].slice(0, LIMIT);
	try {
		localStorage.setItem(KEY, JSON.stringify(next));
	} catch {}
}
function getRecentProducts() {
	return readSlugs().map((s) => getProduct(s)).filter((p) => Boolean(p));
}
function readSlugs() {
	if (typeof window === "undefined") return [];
	try {
		const raw = localStorage.getItem(KEY);
		if (!raw) return [];
		const parsed = JSON.parse(raw);
		return Array.isArray(parsed) ? parsed.filter((s) => typeof s === "string") : [];
	} catch {
		return [];
	}
}
function ProductPage() {
	const { product, related } = Route.useLoaderData();
	const category = getCategory(product.category);
	const openFor = useQuoteStore((s) => s.openFor);
	const { body, specs } = parseDescription(product.description);
	const [recent, setRecent] = (0, import_react.useState)([]);
	(0, import_react.useEffect)(() => {
		pushRecent(product.slug);
		setRecent(getRecentProducts().filter((p) => p.slug !== product.slug).slice(0, 4));
	}, [product.slug]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "mx-auto max-w-6xl px-4 py-8 sm:px-6 sm:py-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Breadcrumbs, { items: [
				{
					label: "Каталог",
					to: "/catalog"
				},
				...category ? [{
					label: category.name,
					to: "/catalog/$category",
					params: { category: category.id }
				}] : [],
				{ label: product.title }
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 grid items-start gap-10 lg:grid-cols-12",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "lg:col-span-7",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductImage, {
						src: product.image,
						alt: product.alt,
						className: "aspect-[4/3] rounded-xl bg-card shadow-[var(--shadow-border)]",
						zoom: true
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "lg:sticky lg:top-24 lg:col-span-5",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl bg-card p-6 shadow-[var(--shadow-border)] sm:p-8",
						children: [
							category ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/catalog/$category",
								params: { category: category.id },
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									variant: "muted",
									children: category.name
								})
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "mt-4 font-sans text-3xl font-semibold tracking-tight text-foreground sm:text-4xl",
								children: product.title
							}),
							product.titleOriginal ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-muted-foreground",
								children: product.titleOriginal
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-5 text-base leading-relaxed text-foreground/90",
								children: product.excerpt
							}),
							specs.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-6 flex flex-wrap gap-2",
								children: specs.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									variant: "outline",
									children: s
								}) }, s))
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-8 flex flex-wrap gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "lg",
									onClick: () => openFor(product),
									children: "Запросить КП"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									asChild: true,
									size: "lg",
									variant: "outline",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
										href: COMPANY.whatsapp,
										target: "_blank",
										rel: "noopener noreferrer",
										children: "WhatsApp"
									})
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-4 text-sm text-muted-foreground",
								children: "Цена, комплектация и срок поставки согласовываются индивидуально."
							})
						]
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-14 border-t border-border pt-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-sans text-2xl font-semibold text-foreground",
					children: "Описание"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 max-w-3xl text-sm leading-relaxed text-muted-foreground sm:text-base",
					children: body || product.description
				})]
			}),
			related.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-16",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-sans text-2xl font-semibold text-foreground",
					children: "В этой категории"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6 grid gap-5 sm:grid-cols-2 lg:grid-cols-4",
					children: related.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductCard, { product: p }, p.slug))
				})]
			}) : null,
			recent.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-16",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-sans text-2xl font-semibold text-foreground",
					children: "Вы смотрели"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6 grid gap-5 sm:grid-cols-2 lg:grid-cols-4",
					children: recent.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductCard, { product: p }, p.slug))
				})]
			}) : null
		]
	});
}
//#endregion
export { ProductPage as component };
