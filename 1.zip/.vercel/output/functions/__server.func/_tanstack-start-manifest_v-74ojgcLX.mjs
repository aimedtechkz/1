//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-74ojgcLX.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/_site"],
		preloads: [
			"/assets/index-CnYYcY4r.js",
			"/assets/jsx-runtime-BkSabwWG.js",
			"/assets/react-DHmoMYoq.js",
			"/assets/link-vJ5bhpwn.js",
			"/assets/useNavigate-vkFzXS1M.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CnYYcY4r.js"
		} }]
	},
	"/_site": {
		filePath: "/workspace/src/routes/_site.tsx",
		children: [
			"/_site/about",
			"/_site/contacts",
			"/_site/privacy",
			"/_site/services",
			"/_site/",
			"/_site/catalog/$category",
			"/_site/product/$slug",
			"/_site/catalog/"
		],
		preloads: [
			"/assets/_site-BStOCh1q.js",
			"/assets/button-o6hHYLWr.js",
			"/assets/_site-Vm413wgs.js",
			"/assets/search-store-BumyTS3z.js",
			"/assets/label-B9lv2JqZ.js",
			"/assets/search-CSs7pq5j.js",
			"/assets/dist-C6QhIH3W.js",
			"/assets/dist-ChDjK3ZT.js",
			"/assets/company-BBIbN-7J.js",
			"/assets/quote-store-Cghh5Ash.js",
			"/assets/input-B3P3ri-F.js"
		]
	},
	"/_site/about": {
		filePath: "/workspace/src/routes/_site/about.tsx",
		children: void 0,
		preloads: ["/assets/about-D9fuhfRh.js"]
	},
	"/_site/contacts": {
		filePath: "/workspace/src/routes/_site/contacts.tsx",
		children: void 0,
		preloads: ["/assets/contacts-BBWouZtL.js"]
	},
	"/_site/privacy": {
		filePath: "/workspace/src/routes/_site/privacy.tsx",
		children: void 0,
		preloads: ["/assets/privacy-DvGXtmd0.js"]
	},
	"/_site/services": {
		filePath: "/workspace/src/routes/_site/services.tsx",
		children: void 0,
		preloads: ["/assets/services-DExY0J-2.js", "/assets/faq-list-D0EDYcAE.js"]
	},
	"/_site/": {
		filePath: "/workspace/src/routes/_site/index.tsx",
		children: void 0,
		preloads: [
			"/assets/_site-yapByta7.js",
			"/assets/category-icons-wHlIKRys.js",
			"/assets/product-card-27Gboq2l.js",
			"/assets/faq-list-D0EDYcAE.js"
		]
	},
	"/_site/catalog/$category": {
		filePath: "/workspace/src/routes/_site/catalog/$category.tsx",
		children: void 0,
		preloads: ["/assets/_category-DWsBl_h9.js", "/assets/catalog-view-zpqerd6t.js"]
	},
	"/_site/product/$slug": {
		filePath: "/workspace/src/routes/_site/product/$slug.tsx",
		children: void 0,
		preloads: ["/assets/_slug-DPHTmVPY.js", "/assets/product-card-27Gboq2l.js"]
	},
	"/_site/catalog/": {
		filePath: "/workspace/src/routes/_site/catalog/index.tsx",
		children: void 0,
		preloads: ["/assets/catalog-BQiru0zR.js", "/assets/catalog-view-zpqerd6t.js"]
	}
} });
//#endregion
export { tsrStartManifest };
